Set fso = CreateObject("Scripting.FileSystemObject")
Set WshShell = CreateObject("WScript.Shell")

scriptDir = fso.GetParentFolderName(WScript.ScriptFullName)
WshShell.CurrentDirectory = scriptDir

' 先杀掉旧 cloudflared 进程（避免端口冲突）
On Error Resume Next
WshShell.Run "taskkill /IM cloudflared.exe /F", 0, True
WScript.Sleep 2000
On Error GoTo 0

' 定位 cloudflared
cfd = scriptDir & "\cloudflared.exe"
If Not fso.FileExists(cfd) Then
    cfd = WshShell.ExpandEnvironmentStrings("%LOCALAPPDATA%") & "\Microsoft\WinGet\Links\cloudflared.exe"
    If Not fso.FileExists(cfd) Then
        cfd = "C:\Cloudflared\cloudflared.exe"
    End If
End If

If Not fso.FileExists(cfd) Then
    MsgBox "找不到 cloudflared.exe，请重新运行 安装.bat", 16, "错误"
    WScript.Quit 1
End If

WshShell.Run """" & cfd & """ access tcp --hostname mcserver.aifam.top --url 127.0.0.1:25565", 0, False