@echo off
chcp 65001 >nul
title Minecraft 隧道 - 请勿关闭此窗口
cd /d "%~dp0"

:: ---------- 清理旧的 cloudflared 进程 ----------
tasklist /FI "IMAGENAME eq cloudflared.exe" 2>nul | find /I "cloudflared.exe" >nul
if %errorlevel% equ 0 (
    echo [INFO] 检测到旧隧道进程，正在清理...
    taskkill /IM cloudflared.exe /F >nul 2>&1
    timeout /t 2 /nobreak >nul
)

:: ---------- 定位 cloudflared ----------
set "CFD="
if exist "cloudflared.exe" set "CFD=%~dp0cloudflared.exe"
if not defined CFD if exist "%LOCALAPPDATA%\Microsoft\WinGet\Links\cloudflared.exe" set "CFD=%LOCALAPPDATA%\Microsoft\WinGet\Links\cloudflared.exe"
if not defined CFD if exist "C:\Cloudflared\cloudflared.exe" set "CFD=C:\Cloudflared\cloudflared.exe"
if not defined CFD (
    where cloudflared >nul 2>&1 && for /f "delims=" %%p in ('where cloudflared') do set "CFD=%%p"
)

if not defined CFD (
    echo [错误] 找不到 cloudflared.exe
    echo 请把它放到本目录，或重新运行 安装.bat
    pause
    exit /b 1
)

echo ========================================
echo   正在连接服务器隧道...
echo   保持本窗口开启，然后打开 HMCL/PCL
echo   服务器地址：127.0.0.1:25565
echo   游戏版本：26.2
echo ========================================
echo.

"%CFD%" access tcp --hostname mcserver.aifam.top --url 127.0.0.1:25565

echo.
echo 隧道已断开，按任意键退出...
pause >nul