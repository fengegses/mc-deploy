@echo off
chcp 65001 >nul
setlocal EnableDelayedExpansion
title Minecraft 客户端安装向导
cd /d "%~dp0"

echo ========================================
echo   Minecraft 客户端安装向导
echo ========================================
echo.
echo [INFO] 当前目录：%CD%
echo.

:: ---------- 1. 检查 cloudflared.exe ----------
set "CFD="
if exist "cloudflared.exe" set "CFD=%~dp0cloudflared.exe"
if not defined CFD if exist "%LOCALAPPDATA%\Microsoft\WinGet\Links\cloudflared.exe" set "CFD=%LOCALAPPDATA%\Microsoft\WinGet\Links\cloudflared.exe"
if not defined CFD if exist "C:\Cloudflared\cloudflared.exe" set "CFD=C:\Cloudflared\cloudflared.exe"
if not defined CFD (
    where cloudflared >nul 2>&1 && for /f "delims=" %%p in ('where cloudflared') do set "CFD=%%p"
)

if not defined CFD (
    echo [错误] 找不到 cloudflared.exe
    echo.
    echo 请从下面下载 cloudflared-windows-amd64.exe：
    echo   https://github.com/cloudflare/cloudflared/releases/latest
    echo 重命名为 cloudflared.exe，放到本目录，再重新运行本脚本
    echo.
    pause
    exit /b 1
)
echo [OK] cloudflared：!CFD!

:: ---------- 2. 验证可执行 ----------
"!CFD!" --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [警告] cloudflared 无法执行，可能被安全软件拦截
    pause
    exit /b 1
)
for /f "tokens=3" %%v in ('"!CFD!" --version 2^>nul') do echo [OK] cloudflared 版本：%%v

:: ---------- 3. 检查启动脚本 ----------
if not exist "启动MC隧道.bat" (
    echo [错误] 本目录下找不到 启动MC隧道.bat
    pause
    exit /b 1
)
echo [OK] 找到 启动MC隧道.bat

if exist "启动MC隧道-静默.vbs" (
    echo [OK] 找到 启动MC隧道-静默.vbs
    set "HAS_SILENT=1"
) else (
    set "HAS_SILENT=0"
)

:: ---------- 4. 创建桌面快捷方式 ----------
echo.
echo [创建] 正在生成桌面快捷方式...

:: 前台版
powershell -NoProfile -Command ^
  "$ws = New-Object -ComObject WScript.Shell;" ^
  "$lnk = $ws.CreateShortcut([Environment]::GetFolderPath('Desktop') + '\启动MC隧道.lnk');" ^
  "$lnk.TargetPath = '%CD%\启动MC隧道.bat';" ^
  "$lnk.WorkingDirectory = '%CD%';" ^
  "$lnk.IconLocation = '%SystemRoot%\System32\SHELL32.dll,77';" ^
  "$lnk.Save()"

if exist "%USERPROFILE%\Desktop\启动MC隧道.lnk" (
    echo [OK] 桌面快捷方式：启动MC隧道.lnk
) else (
    echo [警告] 创建失败，可手动把 启动MC隧道.bat 发送到桌面
)

:: 静默版
if "!HAS_SILENT!"=="1" (
    powershell -NoProfile -Command ^
      "$ws = New-Object -ComObject WScript.Shell;" ^
      "$lnk = $ws.CreateShortcut([Environment]::GetFolderPath('Desktop') + '\启动MC隧道-静默.lnk');" ^
      "$lnk.TargetPath = 'wscript.exe';" ^
      "$lnk.Arguments = '\"%CD%\启动MC隧道-静默.vbs\"';" ^
      "$lnk.WorkingDirectory = '%CD%';" ^
      "$lnk.IconLocation = '%SystemRoot%\System32\SHELL32.dll,137';" ^
      "$lnk.Save()"
    if exist "%USERPROFILE%\Desktop\启动MC隧道-静默.lnk" (
        echo [OK] 桌面快捷方式：启动MC隧道-静默.lnk
    )
)

:: ---------- 5. 完成 ----------
echo.
echo ========================================
echo   安装完成！
echo ========================================
echo.
echo 使用方法：
echo   日常玩：双击桌面"启动MC隧道-静默"，然后开 HMCL 连 127.0.0.1:25565
echo   排查问题：双击桌面"启动MC隧道"，看黑窗口输出
echo.
echo 服务器版本：26.2
echo.
pause